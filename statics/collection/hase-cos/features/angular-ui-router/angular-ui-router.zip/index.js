require('./angular-ui-router');
module.exports = ui-router;
